package Book;

import java.util.Scanner;

public class LibraryApp {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			Libraray lib = new Libraray();
			int choice = 0;

			do {
				System.out.println("");
				System.out.println("1 add new book to list : ");
				System.out.println("2.remove the book from the list : ");
				System.out.println("3.find the all books by given author : ");
				System.out.println("4.find the all bokks fewer than given number of copies avialable : ");
				System.out.println("5.exit: ");
				System.out.println("------------------------");
				System.out.println("Enter your choice: ");
				choice = sc.nextInt();
				sc.nextLine();

				switch (choice) {
				case 1: {
					System.out.println("Enter the title: ");
					String name = sc.nextLine();
					System.out.println("Enter the number of copies: ");
					int n = sc.nextInt();
					lib.addBook(name, n);
				}
					break;

				case 2: {
					System.out.println("Enter the title: ");
					String name = sc.nextLine();
					try {
						lib.loanBook(name);
					} catch (BookUnavailabeException e) {

						System.out.println(e.getMessage());
					}

				}
					break;
				case 3: {
					System.out.println("Enter the title: ");
					String name = sc.nextLine();
					try {
						lib.returnBook(name);
					} catch (BookNotFoundException e) {

						System.out.println(e.getMessage());
					}

				}
					break;
				case 4: {
					lib.showBooks();
				}
					break;
				case 5: {
					System.out.println("bye.....");
				}
				default:
					break;
				}
			} while (choice != 5);
		}
	}
}