

package Book;

import java.util.ArrayList;

public class Libraray {
	ArrayList<Book> alist = new ArrayList<Book>();
	Book b = new Book();

	public Libraray() {
		alist.add(new Book("abc", 5));
		alist.add(new Book("def", 6));
		alist.add(new Book("ghi", 7));
		alist.add(new Book("jkl", 8));
		alist.add(new Book("mno", 9));
	}

	public void addBook(String title, int initialCopies) {
		alist.add(new Book(title, initialCopies));
	}

	public void showBooks() {
		for (Book book : alist) {
			System.out.println(book.toString());
		}
	}

	public void loanBook(String title) throws BookUnavailabeException {
		boolean flag = false;
		for (Book book : alist) {
			if (book.getTitle().equals(title)) {
				flag = true;
				book.setAvailableCopies(book.getAvailableCopies() - 1);

			}
		}
		if (flag == false) {
			throw new BookUnavailabeException("book is not available");
		}
	}

	public void returnBook(String title) throws BookNotFoundException {
		boolean flag = false;
		for (Book book : alist) {
			if (book.getTitle().equals(title)) {
				flag = true;
				book.setAvailableCopies(book.getAvailableCopies() + 1);

			}
		}
		if (flag == false) {
			throw new BookNotFoundException("book is not available");
		}
	}
}