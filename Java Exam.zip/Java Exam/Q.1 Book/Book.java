package Book;

class BookUnavailabeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookUnavailabeException(String s) {
		super(s);
	}

}

class BookNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookNotFoundException(String s) {
		super(s);
	}
}

public class Book {

	private String title;
	private int availableCopies;

	public Book() {
		super();
	}

	public Book(String title, int availableCopies) {
		super();
		this.title = title;
		this.availableCopies = availableCopies;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getAvailableCopies() {
		return availableCopies;
	}

	public void setAvailableCopies(int availableCopies) {
		this.availableCopies = availableCopies;
	}

	@Override
	public String toString() {
		return "Book [title=" + title + ", availableCopies=" + availableCopies + "]";
	}

}