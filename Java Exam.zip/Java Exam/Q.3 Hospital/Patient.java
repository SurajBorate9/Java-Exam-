package Hospital;


public class Patient extends Person {
 private String patientID;
 private String ailment;


 public Patient(String name, int age, String patientID, String ailment) {
     super(name, age);
     if (patientID == null || patientID.isEmpty()) {
         throw new IllegalArgumentException("patientid not be empty.");
     }
     if (ailment == null || ailment.isEmpty()) {
         throw new IllegalArgumentException("ailment not be empty.");
     }
     this.patientID = patientID;
     this.ailment = ailment;
 }


 public Patient(String name, int age) {
     super(name, age);
     this.patientID = "Unknown";
     this.ailment = "Unknown";
 }


 public String getPatientID() {
     return patientID;
 }


 public void setPatientID(String patientID) {
     if (patientID == null || patientID.isEmpty()) {
         throw new IllegalArgumentException("patientid not be empty.");
     }
     this.patientID = patientID;
 }


 public String getAilment() {
     return ailment;
 }


 public void setAilment(String ailment) {
     if (ailment == null || ailment.isEmpty()) {
         throw new IllegalArgumentException("ailment not be empty.");
     }
     this.ailment = ailment;
 }
}


