package Hospital;

public class Main {
 public static void main(String[] args) {
  
     Person person = new Person("vihang lawand", 24);
     System.out.println("person name: " + person.getName());
     System.out.println("person age: " + person.getAge());

    
     Patient patient1 = new Patient("rudresh choudhari", 23, "1", "Flu");
     System.out.println("patient name: " + patient1.getName());
     System.out.println("patient age: " + patient1.getAge());
     System.out.println("patient id: " + patient1.getPatientID());
     System.out.println("patient ailment: " + patient1.getAilment());

    
     Patient patient2 = new Patient("megha shahale ", 35);
     System.out.println("patient name: " + patient2.getName());
     System.out.println("patient age: " + patient2.getAge());
     System.out.println("patient id: " + patient2.getPatientID());
     System.out.println("patient ailment: " + patient2.getAilment());
 }
}
